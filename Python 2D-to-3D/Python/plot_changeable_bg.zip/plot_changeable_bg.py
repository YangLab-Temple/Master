# -*- coding: utf-8 -*-
"""
Created on Tue Apr 18 12:11:38 2023

@author: Wenlan Yu
Temple University Yang Lab
Date: 2023/04/18
"""

import numpy as np
from pandas import read_csv
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
from scipy.ndimage import gaussian_filter
import matplotlib.colors
import matplotlib.gridspec as gridspec
import matplotlib.patches as patches

#%% Set Parameter

#Here is the file you want to plot
filename = "2023_04_19_15_38_36_hCG1N.csv"
#Here is the file name you want to save as
save_name = "hCG1N"

mpl.rcParams['figure.dpi'] = 100
plt.rcParams.update({'font.size': 24})

#You can reduce the pixel size here. This will increase the caculation time. You also need to increase the gaussian_blur_sigma to balance the change.
pixel_size = 0.5
upper_r_boundary = 100
lower_r_boundary = -100
upper_x_boundary = 200
lower_x_boundary = -200

#Set the sigma of gaussian blur filter
gaussian_blur_sigma = 10

#This is a customized color map. Each color contains 6 digits of Hex color codes and 2 digits of transparency range from 00 to FF
my_cmap = matplotlib.colors.LinearSegmentedColormap.from_list("", ["#00000000", "#D8383AFF", "#efafb0FF"], N = 16)

#Change the structure of the pore location
pore_extent = [-50, 50, -70, 70]

#You can add or remove referance line here
referance_line = False
referance_line_coordination = [-90, -20, 20, 100]
referance_font_size = 20
referance_color = "black"

scale_bar = True
scale_bar_size = 20
scale_bar_color = "black"

background_color = "#FFFFFF"

#%% Define funtion
def generate_cycle(df):
    arr = df.values
    x = arr[:, 0]
    y = arr[:, 1]
    y = y[~np.isnan(y)]
    def make_distance_matrix():
        num_pixel = ((upper_r_boundary-lower_r_boundary)/pixel_size)+1
        dmatrix = np.mgrid[lower_r_boundary:upper_r_boundary:(num_pixel * 1j),lower_r_boundary:upper_r_boundary:(num_pixel * 1j)]
        return np.sqrt(np.multiply(dmatrix[0], dmatrix[0])+np.multiply(dmatrix[1], dmatrix[1]))
    binsize = x[0]*2
    dmatrix = make_distance_matrix()/binsize    
    dmatrix = np.floor(dmatrix).astype(int)
    if dmatrix.max() > np.size(y):
        y = np.append(y, np.zeros(dmatrix.max()-np.size(y)+1))
    brightvalue = y[dmatrix]
    return brightvalue

def generate_cycle2(df):
    arr = df.values
    x = arr[:, 0]
    y = arr[:, 1]
    y = y[~np.isnan(y)]
    def make_distance_matrix():
        num_pixel = ((upper_r_boundary*0.7-lower_r_boundary*0.7)/pixel_size)+1
        dmatrix = np.mgrid[lower_r_boundary*0.7:upper_r_boundary*0.7:(num_pixel * 1j),lower_r_boundary*0.7:upper_r_boundary*0.7:(num_pixel * 1j)]
        return np.sqrt(np.multiply(dmatrix[0], dmatrix[0])+np.multiply(dmatrix[1], dmatrix[1]))
    binsize = x[1]
    dmatrix = make_distance_matrix()/binsize    
    dmatrix = np.floor(dmatrix).astype(int)
    if dmatrix.max() > np.size(y):
        y = np.append(y, np.zeros(dmatrix.max()-np.size(y)+1))
    brightvalue = y[dmatrix]
    return brightvalue

"""
Import picture file
"""
img = plt.imread("Picture.png")

"""
Variable initiation
"""
cut_index = int((upper_r_boundary-lower_r_boundary)/(pixel_size*2))
cut_delta = int((upper_r_boundary-lower_r_boundary)/(pixel_size)*0.7/2+1)

#%% Caculating density map
nup_df = read_csv(filename)
nup_colume_name = nup_df.columns.values
num_region = int(len(nup_colume_name)/2)

ring_arr_list = []

for i in range(num_region):
    ring_df = nup_df.iloc[:,2*i:2*i+2]
    ring_range = nup_colume_name[2*i].split("_")[0].replace('[', '').replace(']', '').replace(' ', '').split(",")
    ring_range = [int(float(ring_range[0])),int(float(ring_range[1]))]
            
    ring_brightlevel = generate_cycle(ring_df)
    cut_brightlevel = ring_brightlevel[cut_index]
    tiled_cut_brightlevel = np.tile(cut_brightlevel,(int((ring_range[1]-ring_range[0])/pixel_size),1))
    
    if i == 0:
        combined_cut_df = np.zeros((int((ring_range[0]-lower_x_boundary)/pixel_size), int((upper_r_boundary-lower_r_boundary)/pixel_size+1)))
        nup_range_list = [ring_range[0]]
            
    combined_cut_df = np.concatenate((combined_cut_df, tiled_cut_brightlevel), axis=0)
    nup_range_list.append(ring_range[1])
    
    if i == int(num_region-1):
        combined_cut_df = np.concatenate((combined_cut_df, np.zeros((int((upper_x_boundary-ring_range[1])/pixel_size), int((upper_r_boundary-lower_r_boundary)/pixel_size+1)))), axis=0)

combined_cut_df = combined_cut_df/combined_cut_df.max()

combined_cut_df_bak = combined_cut_df

combined_cut_df = gaussian_filter(combined_cut_df, sigma = gaussian_blur_sigma)

for i in range(num_region):
    ring_index = (((nup_range_list[i+1]-nup_range_list[i])/2+nup_range_list[i])-lower_x_boundary)/pixel_size
    arr1 = np.arange(0,upper_r_boundary+pixel_size,pixel_size)
    arr2 = combined_cut_df[int(ring_index),cut_index:]
    temp_df = pd.DataFrame(np.vstack([arr1,arr2]).T, columns = ['Bin Center','Probability'])
    
    ring_brightlevel = generate_cycle2(temp_df)
    ring_arr_list.append(ring_brightlevel)

"""
Variable initiation for plotting
"""
r_bin_num = int((upper_r_boundary-lower_r_boundary)/pixel_size+1)

#%% Figure Plot
fig = plt.figure(figsize=(10,5))
gs = gridspec.GridSpec(nrows=5, ncols=10)
ax = plt.subplot(gs[0:5, 0:10])
plt.subplots_adjust(top = 1, bottom = 0, right = 1, left = 0, hspace = 0, wspace = 0)
#ax_color_bar = plt.subplot(gs[1:4, 10:11])
rect = patches.Rectangle((lower_x_boundary, lower_r_boundary), (upper_x_boundary - lower_x_boundary), (upper_r_boundary - lower_r_boundary), linewidth=0, edgecolor='none', facecolor=background_color, zorder = 0)
ax.add_patch(rect)

im = ax.imshow(combined_cut_df.T, cmap = my_cmap, extent =[lower_x_boundary, upper_x_boundary, lower_r_boundary, upper_r_boundary], zorder = 1)
#ax.imshow(img, extent=pore_extent, zorder=5, alpha = 0.5)
ax.axis('off')
ax.axis('equal')
ax.set_xlim([lower_x_boundary,upper_x_boundary])
ax.set_ylim([lower_r_boundary,upper_r_boundary])
# ax.annotate("Axial Dimension (nm)", xy=(0, upper_r_boundary), ha='center', va='bottom',fontsize = 20, rotation = 0)
# ax.annotate("Radial Dimension (nm)", xy=(lower_x_boundary*1.01, 0), ha='right', va='center',fontsize = 20, rotation = 90)
# ax.annotate("C", xy=(lower_x_boundary*0.97, upper_r_boundary*0.97), ha='left', va='top',fontsize = 35, fontweight = "bold", rotation = 0, color = "white")
# ax.annotate("N", xy=(upper_x_boundary*0.97, upper_r_boundary*0.97), ha='right', va='top',fontsize = 35, fontweight = "bold", rotation = 0, color = "white")

if referance_line == True:
    for i in referance_line_coordination:
        ax.text(x = i, y = lower_r_boundary*1.01, s = str(i), ha = "center", va = "top", fontsize = referance_font_size)
        ax.axvline(x=i, color = referance_color, ls = "--", lw = 2, ymin = 0, ymax = 1)

# fig.colorbar(im, cax=ax_color_bar, aspect = 20, extend = "neither", ticks = [])
# ax_color_bar.annotate("Low", xy=(0.5, 0), ha='center', va='top',fontsize = 25, fontweight = "bold", rotation = 0)
# ax_color_bar.annotate("High", xy=(0.5, combined_cut_df.max()), ha='center', va='bottom',fontsize = 25, fontweight = "bold", rotation = 0)

if scale_bar == True:
    line_x1 = [185 - scale_bar_size, 185]
    line_y1 = [-95, -95]
    ax.plot(line_x1, line_y1, linewidth=5, linestyle = "-", color = scale_bar_color)

plt.savefig(save_name, bbox_inches='tight', pad_inches = 0, dpi=300)

for ring_index, ring_arr in enumerate(ring_arr_list):
    fig, ax = plt.subplots(1,1,figsize=(5,5))
    plt.subplots_adjust(top = 1, bottom = 0, right = 1, left = 0, hspace = 0, wspace = 0)
    rect = patches.Rectangle((lower_r_boundary, lower_r_boundary), (upper_r_boundary - lower_r_boundary), (upper_r_boundary - lower_r_boundary), linewidth=0, edgecolor='none', facecolor=background_color, zorder = 0)
    ax.add_patch(rect)
    ax.imshow(ring_arr, cmap = my_cmap, vmax = combined_cut_df.max(),extent = [lower_r_boundary, upper_r_boundary, lower_r_boundary, upper_r_boundary], zorder = 1)
    ax.axis('off')
    ax.axis('equal')
    save_name_ring = save_name + "[" + str(nup_range_list[ring_index]) + "," + str(nup_range_list[ring_index+1])+"]"
    fig.savefig(save_name_ring, bbox_inches='tight', pad_inches = 0, dpi=300)
    
    if scale_bar == True:
        line_x1 = [95 - scale_bar_size, 95]
        line_y1 = [-95, -95]
        ax.plot(line_x1, line_y1, linewidth=5, linestyle = "-", color = scale_bar_color)
