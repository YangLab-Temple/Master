import numpy as np
import pandas as pd
import math
from scipy.stats import mannwhitneyu
from scipy.signal import savgol_filter
import datetime
from colorama import Fore
from scipy.ndimage import gaussian_filter1d

#Settings
##Set the upper limit of the R dimensional data. This upper limit is a soft cap, which will be rounded up depanding of the bin size of the analysis. 
    ##For example, if you set the upper limit to 100 and bin size to 6, the real upper limit will be set to 102
    ##Observations exceeding the upper limit will be excluded from the analysis, or caculated as the background noise (please check the background_filter function at the end of the setting). 
    ##Please do not go too crazy about the range, as it will exponentially increase the computing power requirement.
R_upperlimit = 150
##Set the setting file name.
filename = "Output_200Points.csv"
##Set the range of bin size you would like to analysis. If you only like to analysis one bin size, set both to the same number.
bin_min = 4
bin_max = 12
##Set the separate point on the X dimension so each region will be analyzed separately
    ##For the NPC, the separate points are tipically set to -20 and 20. For example: 
        ##separate_point = [-20, 20], or if you would like to add additional seprate point:
        ##separate_point = [-20, 0, 20]
    ##The separate point could be set to None for subcellular structures without subregion such as cilia. For example: 
        ##separate_point = None
#separate_points = [-140,-130,-120,-110,-100,-90,-80,-70,-60,-50,-40,-30,-20,-10,0,10,20,30,40,50,60,70,80,90,100,110,120,130,140]
#separate_points = [-110,-70,-20,20,100,125]
##Set smoothing method and intensity. Two smoothing method could be apply to the data:
    ##1) "gaussian_filter1d"
    ##2) "savgol_filter"
smoothing_method = None
    ##1 Dimension Gaussian Filter requires one parameter: sigma
gaussian_filter_sigma = 1
    ##Savitzky–Golay filter, which required two parameters:
        ## 1. smoothing_window_length: The length of the filter window (i.e., the number of coefficients).
        ## 2. smoothing_window_polyorder: The order of the polynomial used to fit the samples. Polyorder must be less than window_length.
        ## For no smoothing, set smoothing_window_length = 1 and smoothing_window_polyorder = 0
savgol_filter_length = 5
savgol_filter_polyorder = 1
##Set output normalization method: 
    ## 1. "single_region", for fitting the R data in a single subregion
    ## 2. "multi_region", for comparing density between different subregions
    ## 3. None, for checking the origional data
normalization = None
normalization_zero_negative = True
normalization_min_max = False
##Set how you would like to sort the data frame in the output file: 
    ## 1. "subregion": All data from the same subregion will be grouped together with different bin size next to each other. Ideal for fitting.
    ## 2. "bin": All data from the same bin size will be grouped together with different subregion next to each other. Ideal for comparison between different subregions.
save_format = "subregion"
##Set the Mann–Whitney U test threshold for symmetry test. Any p-value caculated below the threshold will display a warning messege to the console and write in the warning note file.
MWU_threshold = 0.001
##Set the ON/OFF for the background_filter funtion. The filter helps filtering out background noise outside of the radial symmetry system, which could be helpful when encounting universially distributed background locolization.
background_filter = True
background_filter_range = 180

def data_filter (df, x_data_range):
    global warning
    newdf = df.loc[(df['X'] >= x_data_range[0]) & (df['X'] <= x_data_range[1])]
    y_data_df = newdf["Y"]
    y_data_df_positive = y_data_df.loc[(y_data_df >= 0)]
    y_data_df_negative = y_data_df.loc[(y_data_df <= 0)]
    result = mannwhitneyu(abs(y_data_df_negative), y_data_df_positive, method="auto")
    y_data_df = abs(y_data_df)
    if result.pvalue < MWU_threshold:
        warning += "Caution!!! Please be aware that the Y dimensional data for " + row["File"] + " range: " + str(y) + " does not seem symmetrical over 0. The p-value calculated by using Mann–Whitney U test = " + str(result.pvalue) + "\n"     
    return y_data_df

def X_sepration(range_min,range_max,separate_points):
    def seprate(list_of_range, separate_point):
        templist = list_of_range
        for i in list_of_range:
            if separate_point > i[0] and separate_point < i[1]:
                templist.remove(i)
                templist.append([i[0],separate_point])
                templist.append([separate_point,i[1]])
        return templist
    range_list = [[range_min,range_max]]
    for i in separate_points:
        range_list = seprate(range_list,i)
    return range_list

def TwoD_to_ThreeD(binsize, upperlimit, listofnumber):
    binnumber = math.ceil(upperlimit/binsize)+1
    def create_matrix(binsize, upperlimit):
        def caculate_S(i, j, binsize):
            S_area = (np.arccos((j-1)/i)*(i**2)*(binsize**2))/2-((math.sqrt((i**2)-((j-1)**2))/i)*((j-1)/i)*(i**2)*(binsize**2))/2
            return S_area
        area_matrix = np.zeros([binnumber, binnumber], dtype = "f8")
        for i in range(binnumber):
            for j in range(binnumber):
                if j > i or i == binnumber-1:
                    break
                elif i == j:
                    A_i_j = caculate_S(i+1, j+1, binsize)
                else:
                    A_i_j = caculate_S(i+1, j+1, binsize)-caculate_S(i, j+1, binsize)-caculate_S(i+1, j+2, binsize)+caculate_S(i, j+2, binsize)
                area_matrix[i,j] = A_i_j
        area_matrix_sum = np.sum(area_matrix,axis=0)
        area_matrix_bg=np.empty(binnumber); area_matrix_bg.fill(binsize*background_filter_range)
        area_matrix_bg[binnumber-1] = (background_filter_range-(math.ceil(upperlimit/binsize)*binsize))*background_filter_range
        area_matrix[binnumber-1,] = area_matrix_bg-area_matrix_sum
        return area_matrix
    area_matrix = create_matrix (binsize,upperlimit)
    hist, edges = np.histogram(listofnumber,bins=math.ceil(upperlimit/binsize),range=(0, binsize*math.ceil(upperlimit/binsize)),density=False)
    frequency_count=np.empty(binnumber)
    frequency_count[0:binnumber-1] = hist
    if background_filter == True and background_filter_range > R_upperlimit:
        hist_bg, edges_bg = np.histogram(listofnumber,bins=1,range=(binsize*math.ceil(upperlimit/binsize), background_filter_range),density=False)
        frequency_count[binnumber-1] = hist_bg
    area_matrix_Tinv = np.linalg.inv(area_matrix.T)
    density_matrix = np.matmul(area_matrix_Tinv, frequency_count)
    return density_matrix[0:binnumber-1]

def df_normalization(norm_df):
    if normalization == None:
        return norm_df
    if normalization_zero_negative == True:
        norm_df[norm_df<0] = 0
    if normalization == "single_region":
        if normalization_min_max == False:
            norm_df.iloc[:, 1::2] = norm_df.iloc[:, 1::2]/norm_df.iloc[:, 1::2].max()
        if normalization_min_max == True:
            norm_df.iloc[:, 1::2] = (norm_df.iloc[:, 1::2]-norm_df.iloc[:, 1::2].min())/(norm_df.iloc[:, 1::2].max()-norm_df.iloc[:, 1::2].min())
    if normalization == "multi_region":
        for i in range(num_bin):
            max_value = norm_df.iloc[:, 2*i+1::2*num_bin].max().max()
            min_value = norm_df.iloc[:, 2*i+1::2*num_bin].min().min()
            if normalization_min_max == False:
                norm_df.iloc[:, 2*i+1::2*num_bin] = norm_df.iloc[:, 2*i+1::2*num_bin]/max_value
            if normalization_min_max == True:
                norm_df.iloc[:, 2*i+1::2*num_bin] = (norm_df.iloc[:, 2*i+1::2*num_bin]-min_value)/(max_value-min_value)
    return norm_df

now = datetime.datetime.now()        
df = pd.read_csv (filename)
warning =""
for index, row in df.iterrows():
    separate_points = row["Cutpoint"].replace('[', '').replace(']', '').split(",")
    separate_points = [eval(i) for i in separate_points]
    try:
        tempdf = pd.read_csv (row["File"],header=None,names=["X","Y"])
    except:
        warning += "WARNING!!! The file named " + row["File"] + " could not be found.\n"
        continue
    if row["Range_max"] < row["Range_min"]:
        warning += "WARNING!!! Please check the range for file named " + row["File"] + " in the setting file:" + filename + ". Maximum range is smaller than the minimum range.\n"
        continue
    if separate_points != None:
        x_range = X_sepration(row["Range_min"],row["Range_max"],separate_points)
    else:
        x_range = [row["Range_min"],row["Range_max"]]
    result_df = pd.DataFrame()
    for y in x_range:
        try:
            y_data = data_filter(tempdf,y)
        except:
            y_data = []
        for x in np.arange(bin_min, bin_max+0.05, 0.05):
            binsize = round(x, 2)
            prob = TwoD_to_ThreeD(binsize, R_upperlimit, y_data)
            prob = prob/(y[1]-y[0])
            
            if smoothing_method == "savgol_filter":
                try:
                    prob = savgol_filter(prob, savgol_filter_length, savgol_filter_polyorder, mode="nearest")
                except Exception:
                    warning += "WARNING!!! Polyorder must be less than window_length. No smoothing will be conducted.\n"
                    pass
            if smoothing_method == "gaussian_filter1d":
                prob = gaussian_filter1d(prob, gaussian_filter_sigma)
            bin_center = np.arange(binsize,binsize*(1+math.ceil(R_upperlimit/binsize)),binsize)-(binsize/2)
            if len(bin_center)>len(prob):
                bin_center = bin_center[:-1]
            prob_df = pd.DataFrame([bin_center,prob]).T
            prob_df.columns = [str(y)+"_Bin"+str(binsize)+"_BinCenter",str(y)+"_Bin"+str(binsize)+"_Probability"]
            result_df = pd.concat([result_df, prob_df], axis=1)
    num_bin = bin_max - bin_min + 1
    result_df = df_normalization(result_df)
    if save_format == "bin":
        temp_result_df = pd.DataFrame()
        for x in range(num_bin): 
            for y in range(len(x_range)):
                temp_index = num_bin*2*y+2*x
                temp_prob_df = result_df.iloc[:,temp_index:temp_index+2]
                temp_result_df = pd.concat([temp_result_df, temp_prob_df], axis=1)
        result_df = temp_result_df
    
    filename_save = str(now.strftime('%Y_%m_%d_%H_%M_%S'))+ "_" + row["File"]
    result_df.to_csv(filename_save,index=False)

filename_setting = str(now.strftime('%Y_%m_%d_%H_%M_%S')) + "_setting" + ".txt"
filename_warning = str(now.strftime('%Y_%m_%d_%H_%M_%S')) + "_warning" + ".txt"    
print (Fore.RED + warning)
with open(filename_warning, 'w', encoding='utf-8') as f:
    f.write(warning)
    f.close()
    
setting_txt1 = "R_upperlimit = " + str(R_upperlimit) + "\n" + "Setting file name: " + str(filename) + "\n" + "Bin range: " + str(bin_min) + " to " + str(bin_max) + "\n" 
setting_txt2 = "separate_points = " + str(separate_points) + "\n" + "Smoothing method" + str(smoothing_method) + "\n" + "Gaussian Filter Sigma" + str(gaussian_filter_sigma) + "\n" + "savgol_filter_length = " + str(savgol_filter_length) + "\n" + "savgol_filter_polyorder = " + str(savgol_filter_polyorder) + "\n" 
setting_txt3 = "normalization = " + str(normalization) + "\n" + "normalization_zero_negative = " + str(normalization_zero_negative) + "\n" + "normalization_min_max = " + str(normalization_min_max) + "\n" 
setting_txt4 = "MWU_threshold = " + str(MWU_threshold) + "\n" + "background_filter = " + str(background_filter) + "\n" + "background_filter_range = " + str(background_filter_range) + "\n" 

with open(filename_setting, 'w', encoding='utf-8') as f:
    f.write(setting_txt1+setting_txt2+setting_txt3+setting_txt4)
    f.close()