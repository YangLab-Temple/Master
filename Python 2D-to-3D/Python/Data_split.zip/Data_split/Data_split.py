# -*- coding: utf-8 -*-
"""
Created on Thu Apr  6 17:40:34 2023

@author: wenla
"""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import pandas as pd
from scipy.stats import norm
from scipy.ndimage import gaussian_filter
import matplotlib.colors
import matplotlib.patches as patches

#%% Set Parameter
Data_cutoff = 100
num_datapoints = 200

filename_list = ["Nup358N.csv"]
X_center_list = [-48]

XY_header = False

#%% Code Body
range_min_list = []
range_max_list = []
cutpoint_list = []
hist_num_list = []

for index, file in enumerate(filename_list):
    
    if XY_header == False:
        nup_df = pd.read_csv(file, header = None)
        nup_df_x = nup_df[0]
    else: 
        nup_df = pd.read_csv(file)
        nup_df_x = nup_df["X"]
    
    
    left_end = False
    right_end = False
    
    for i in range(int(Data_cutoff/2)):
        hist, bin_edges = np.histogram(nup_df_x, bins=1, range=(X_center_list[index]-i-1,X_center_list[index]+i+1))
        if hist >= num_datapoints:
            x_bin_edges = [int(bin_edges[0]),int(bin_edges[1])]
            hist_num = [hist[0]]
            break
    
    for m in range(20):
        if left_end == True:
            break
        else:
            for n in range(Data_cutoff):
                hist, bin_edges = np.histogram(nup_df_x, bins=1, range=(x_bin_edges[0]-n-1,x_bin_edges[0]))
                if hist >= num_datapoints:
                    x_bin_edges = [int(bin_edges[0])]+x_bin_edges
                    hist_num = [hist[0]]+hist_num
                    break
                elif n == Data_cutoff-1:
                    left_end = True
                    
    for m in range(20):
        if right_end == True:
            break
        else:
            for n in range(Data_cutoff):
                hist, bin_edges = np.histogram(nup_df_x, bins=1, range=(x_bin_edges[-1],x_bin_edges[-1]+n+i))
                if hist >= num_datapoints:
                    x_bin_edges = x_bin_edges+[int(bin_edges[1])]
                    hist_num = hist_num+[hist[0]]
                    break
                elif n == Data_cutoff-1:
                    right_end = True
        
    range_min_list.append(x_bin_edges[0])
    range_max_list.append(x_bin_edges[-1])
    cutpoint_list.append(x_bin_edges)
    hist_num_list.append(hist_num)
    
    plot_bin_edges = np.arange(-200,201,10)
    fig, ax = plt.subplots(1,1)
    ax.hist(nup_df_x, bins= plot_bin_edges, density = True)
    for i in x_bin_edges:
        ax.axvline(x=i, color = "grey", ls = "--", lw = 2, ymin = 0, ymax = 1)
    ax.set_xlabel("X Dimension (nm)", fontsize = 10, fontweight ='bold')
    ax.set_ylabel("Probability \n Density", fontsize = 10, fontweight ='bold')
    
setting_df = pd.DataFrame(list(zip(filename_list, range_min_list, range_max_list, cutpoint_list, hist_num_list)), columns =['Files', 'Range_min', "Range_max", "Cutpoint", "Localization Count"])

save_name = "Output_"+str(num_datapoints)+"Points.csv"

setting_df.to_csv(save_name, index = False)