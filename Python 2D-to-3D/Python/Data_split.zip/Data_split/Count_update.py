# -*- coding: utf-8 -*-
"""
Created on Fri May 12 11:17:02 2023

@author: wenla
"""

import glob
import pandas as pd
import numpy as np
#%% Set Parameter
XY_header = False

#%% Code Body
for file in glob.glob("Output_*.csv"):
    hist_num_list = []
    setting_df = pd.read_csv(file)
    
    for index, row in setting_df.iterrows():
        
        if XY_header == False:
            nup_df = pd.read_csv(row["Files"], header = None)
            nup_df_x = nup_df[0]
        else: 
            nup_df = pd.read_csv(row["Files"])
            nup_df_x = nup_df["X"]
        
        hist_num = []
        cut_list = row["Cutpoint"]
        cut_list = cut_list.replace("[","").replace("]","").split(', ')
        cut_list = [eval(i) for i in cut_list]
        
        for cut_index, cut in enumerate(cut_list[:-1]):
            hist, bin_edges = np.histogram(nup_df_x, bins=1, range=(cut_list[cut_index],cut_list[cut_index+1]))
            hist_num.append(hist[0])

        hist_num_list.append(hist_num)
    setting_df["Localization Count"] = hist_num_list
    setting_df.to_csv(file, index = False)